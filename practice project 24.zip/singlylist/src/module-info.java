/**
 * 
 */
/**
 * 
 */
module singlylist {
}