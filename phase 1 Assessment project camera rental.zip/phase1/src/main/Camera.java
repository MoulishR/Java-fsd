package main;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
class Camera {
private Scanner scanner = new Scanner(System.in);
void options() {
String[] opt = {
"1. ADD",
"2. REMOVE",
"3. VIEW MY CAMERAS",
"4. GO TO PREVIOUS MENU"
};
for (String option : opt) {
System.out.println(option);
}
try
{
String choice = scanner.nextLine();
switch(Integer.parseInt(choice))
{
case 1:
add();
options();
break;
case 2:
removeCam();
options();
break;
case 3:
viewMycam();
options();
break;
case 4:
Main.mainMenu();
break;
default: 
System.out.println("INVALID OPTION");
options();
break;
}
}catch (Exception e) {
System.out.println("An error occurred. Please try again.");
}
}
void add() {
int lastId = 0;
if (!Main.cameraList.isEmpty()) {
ArrayList<String> lastRow = 
Main.cameraList.get(Main.cameraList.size() - 1);
lastId = Integer.parseInt(lastRow.get(0));
}
ArrayList<String> row = new ArrayList<>();
String id = String.valueOf(lastId + 1);
System.out.print("ENTER THE CAMERA BRAND - ");
String brand = scanner.nextLine();
System.out.print("ENTER THE MODEL - ");
String model = scanner.nextLine();
System.out.print("ENTER THE PER DAY PRICE (INR) - ");
String price = scanner.nextLine();
String status = "Available";
row.add(id);
row.add(brand);
row.add(model);
row.add(price);
row.add(status);
Main.cameraList.add(row);
System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
}
void viewMycam()
{
System.out.println("================================================================");
System.out.println(" CAMERA ID BRAND MODEL PRICE(PER DAY) STATUS ");
System.out.println("================================================================");
for (ArrayList<String> row : Main.cameraList) {
System.out.printf(" %-4s %-10s %-6s %-7s %-8s %n",
row.get(0), row.get(1), row.get(2), row.get(3), row.get(4));
}
System.out.println("================================================================"
);
}
void removeCam()
{
viewMycam();
Scanner scanner = new Scanner(System.in);
System.out.print("ENTER THE CAMERA ID TO REMOVE - ");
String idToRemove = scanner.nextLine();
boolean found = false;
for (ArrayList<String> row : Main.cameraList)
{
if (row.get(0).equals(idToRemove))
{
Main.cameraList.remove(row);
found = true;
break;
}
}
if (found) {
System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
}
else {
System.out.println("CAMERA ID " + idToRemove + " NOT FOUND IN THE LIST.");
}
}
}

