package main;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
class WelcomeNote {
WelcomeNote() {
System.out.println("+-------------------------------+");
System.out.println("| WELCOME TO CAMERA RENTAL APP |");
System.out.println("+-------------------------------+\n");
}
boolean loginPage() {
Scanner input = new Scanner(System.in);
System.out.print("PLEASE LOGIN TO CONTINUE - \nUSERNAME - ");
String username = input.nextLine();
System.out.print("PASSWORD - ");
String password = input.nextLine();
if (username.equals("admin") && password.equals("admin123")) {
return true;
} else {
System.out.println("INCORRECT USERNAME OR PASSWORD");
return loginPage();
}
}
}

