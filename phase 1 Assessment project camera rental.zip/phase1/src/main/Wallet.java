package main;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
public class Wallet {
double balance;
Wallet() {
this.balance = 1052;
}
void displayBalanceAndDeposit() {
try
{
Scanner input = new Scanner(System.in);
System.out.println("YOUR CURRENT WALLET BALANCE IS - INR."+ 
balance);
System.out.print("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET?(1.YES 2.NO) - ");
int choice = input.nextInt();
if (choice==1) {
System.out.print("ENTER THE AMOUNT (INR) - ");
double amount = input.nextDouble();
balance += amount;
System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE - INR."+balance);
} else {
System.out.println("No money deposited.");
}
}catch (Exception e) {
System.out.println("An error occurred. Please try again.");
}
}
boolean hasEnoughBalance(double amount) {
return balance >= amount;
}
} 
