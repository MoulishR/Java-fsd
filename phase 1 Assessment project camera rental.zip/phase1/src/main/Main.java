package main;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
public class Main {
private static boolean loginStatus = false;
private static Camera optObj = new Camera();
private static CameraRental rent_obj = new CameraRental();
public static Wallet wallet_obj = new Wallet();
public static ArrayList<ArrayList<String>> cameraList = new ArrayList<>(
Arrays.asList(
new ArrayList<>(Arrays.asList("1", "Samsung", "DS123", "500.0", 
"Rented")),
new ArrayList<>(Arrays.asList("2", "Sony", "HD214", "500.0", 
"Available")),
new ArrayList<>(Arrays.asList("3", "Panasonic", "XC", "700.0", "Rented")),
new ArrayList<>(Arrays.asList("4", "Canon", "XLR", "1000.0", 
"Available")),
new ArrayList<>(Arrays.asList("5", "Nikon", "2030", "500.0", "Available"))
)
);
public static void main(String[] args) {
Main obj = new Main();
WelcomeNote loginObj = new WelcomeNote();
if (!loginStatus) {
loginStatus = loginObj.loginPage();
}
obj.mainMenu();
}
static void mainMenu() {
String[] mainMenu = {
"1. MY CAMERA",
"2. RENT A CAMERA",
"3. VIEW ALL CAMERAS",
"4. MY WALLET",
"5. EXIT"
};
for (String option : mainMenu) {
System.out.println(option);
}
try
{
Scanner input = new Scanner(System.in);
int opt = input.nextInt();
switch (opt) 
{
case 1:
optObj.options();
break;
case 2:
rent_obj.rentCamera(wallet_obj);
mainMenu();
break;
case 3:
optObj.viewMycam();
mainMenu();
break;
case 4:
wallet_obj.displayBalanceAndDeposit();
mainMenu();
break;
case 5:
break;
default:
System.out.println("INVALID OPTION..!");
mainMenu();
break;
}
}catch (Exception e) {
System.out.println("An error occurred. Please try again.");
}
}
}
