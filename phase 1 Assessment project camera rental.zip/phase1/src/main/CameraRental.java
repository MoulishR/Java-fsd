package main;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
class CameraRental
{
void displayAvailableCameras() {
System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S) - ");
System.out.println("================================================================");
System.out.printf("%-5s %-15s %-15s %-10s %-8s\n", "ID", "Brand", "Model", 
"Price", "Status");
System.out.println("================================================================");
for (ArrayList<String> camera : Main.cameraList) {
String status = camera.get(4);
if (status.equals("Available")) {
System.out.printf("%-5s %-15s %-15s %-10s %-8s\n",
camera.get(0), camera.get(1), camera.get(2), camera.get(3), 
camera.get(4));
}
}
System.out.println("================================================================");
}
void rentCamera(Wallet wallet_obj)
{
displayAvailableCameras();
Scanner input = new Scanner(System.in);
//MyWallet wallet_ob = new MyWallet();
System.out.print("ENTER THE CAMERA ID YOU WANT TO RENT - ");
String id = input.nextLine();
boolean found = false;
for (ArrayList<String> camera : Main.cameraList) {
if (camera.get(0).equals(id) && camera.get(4).equals("Available")) {
double price = Double.parseDouble(camera.get(3));
if(wallet_obj.hasEnoughBalance(price))
{
camera.set(4, "Rented");
found = true;
System.out.println("YOUR TRANSACTION FOR CAMERA -"+camera.get(1)+ " WITH RENT " + price + " HAS SUCCESSFULLY COMPLETED.");
wallet_obj.balance -= price;
break;
}
else
{
found = true;
System.out.println("ERROR : TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE. PLEASE DEPOSIT THE AMOUNT TO YOUR WALLET. ");
break;
}
}
}
if (!found) {
System.out.println("CAMERA WITH ID " + id + " IS NOT FOUND.");
}
}
}
