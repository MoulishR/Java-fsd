/**
 * 
 */
/**
 * 
 */
module regularExpnAssisted {
}