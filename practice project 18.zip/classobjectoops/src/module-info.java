/**
 * 
 */
/**
 * 
 */
module classobjectoops {
}