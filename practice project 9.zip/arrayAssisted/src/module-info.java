/**
 * 
 */
/**
 * 
 */
module arrayAssisted {
}