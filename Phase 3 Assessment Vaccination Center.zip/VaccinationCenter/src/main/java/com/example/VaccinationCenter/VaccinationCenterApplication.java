package com.example.VaccinationCenter;
 import java.time.LocalDateTime;
 import java.util.ArrayList;
 import java.util.List;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.boot.SpringApplication;
 import org.springframework.boot.autoconfigure.SpringBootApplication;
 import org.springframework.boot.autoconfigure.domain.EntityScan;
 import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
 import com.vc.entity.Citizens;
 import com.vc.entity.Users;
 import com.vc.entity.VaccinationCenter;
 import com.vc.service.CitizenService;
 import com.vc.service.UsersService;
 import com.vc.service.VaccinationcenterService;
 import jakarta.annotation.PostConstruct;
 @SpringBootApplication(scanBasePackages = "com")
 @EntityScan(basePackages = "com.vc.entity")
 @EnableJpaRepositories(basePackages = "com.vc.repository")
 public class VaccinationCenterApplication {
 @Autowired
 UsersService usersService;
 @Autowired
 CitizenService citizenService;
 @Autowired
 VaccinationcenterService vaccinationcenterService;
 @PostConstruct
 public void init() {
 System.out.println("This method called........");
 Users user = new Users();
 user.setEmailid("NaveenVarma@gmail.com");
 user.setPassword("Salaar");
 System.out.println(usersService.signUp(user));
 //VaccinationCenters
 VaccinationCenter vc1 = new VaccinationCenter(10,"Hsp-1", "D-1", 
LocalDateTime.of(2024, 12, 23, 3, 10, 12, 3260000), 220);
 VaccinationCenter vc2 = new VaccinationCenter(20,"Hsp-2", "D-3", 
LocalDateTime.of(2024, 12, 29, 3, 18, 12, 326000), 220);
 VaccinationCenter vc3 = new VaccinationCenter(30,"Hsp-3", "D-2", 
LocalDateTime.now(), 200);
 List<VaccinationCenter> lc1 = new ArrayList<>();
lc1.add(vc1);
 lc1.add(vc2);
 lc1.add(vc3);
 VaccinationCenter vc4 = new VaccinationCenter(40,"Hsp-4", "D-2", 
LocalDateTime.of(2024, 12, 20, 12, 55, 45, 509809), 230);
 VaccinationCenter vc5 = new VaccinationCenter(50,"Hsp-5", "D-1", 
LocalDateTime.now(), 230);
 List<VaccinationCenter> lc2 = new ArrayList<>();
 lc2.add(vc4);
 lc2.add(vc5);
 VaccinationCenter vc6 = new VaccinationCenter(60,"Hsp-6", "D-1", 
LocalDateTime.now(), 240);
 List<VaccinationCenter> lc3 = new ArrayList<>();
 lc3.add(vc6);
 VaccinationCenter vc7 = new VaccinationCenter(7,"Hsp-6", "D-3", 
LocalDateTime.of(2024, 1, 2, 1, 22, 22, 324560000), 250);
 VaccinationCenter vc8 = new VaccinationCenter(8,"Hsp-4", "D-2", 
LocalDateTime.of(2024, 1, 6, 4, 32, 45, 3245600), 250);
 VaccinationCenter vc9 = new VaccinationCenter(9,"Hsp-3", "D-1", 
LocalDateTime.of(2024, 1, 8, 2, 10, 11, 560000), 250);
 List<VaccinationCenter> lc4 = new ArrayList<>();
 lc4.add(vc7);
 lc4.add(vc8);
 lc4.add(vc9);
 System.out.println(vaccinationcenterService.storeVaccinationcenterDetails(vc1));
 System.out.println(vaccinationcenterService.storeVaccinationcenterDetails(vc2));
 System.out.println(vaccinationcenterService.storeVaccinationcenterDetails(vc3));
 System.out.println(vaccinationcenterService.storeVaccinationcenterDetails(vc4));
 System.out.println(vaccinationcenterService.storeVaccinationcenterDetails(vc5));
 System.out.println(vaccinationcenterService.storeVaccinationcenterDetails(vc6));
 System.out.println(vaccinationcenterService.storeVaccinationcenterDetails(vc7));
 //Citizens
 Citizens cc1 = new 
Citizens(200,"RanVijaySingh",35,"Male","4343434","Mumbai","Maharastra","543432",
 lc1);
 Citizens cc2 = new 
Citizens(210,"Devaratha_Salaar",43,"Male","43434","Salaar","Khansaar","5432",lc2
 );
 Citizens cc3 = new 
Citizens(220,"Pushpa",38,"Male","434334","chithoor","Andhrapradesh","54432",lc3)
 ;
 Citizens cc4 = new 
Citizens(230,"jessy",32,"female","343434","Alpiri","kerala","43432",lc4);
System.out.println(citizenService.storeCitizenDetails(cc1));
 System.out.println(citizenService.storeCitizenDetails(cc2));
 System.out.println(citizenService.storeCitizenDetails(cc3));
 System.out.println(citizenService.storeCitizenDetails(cc4));
 }
 public static void main(String[] args) {
 SpringApplication.run(VaccinationCenterApplication.class, args);
 System.out.println("Spring boot up.....");
 }
 }