 package com.vc.service;
 import java.util.List;
 import java.util.Optional;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.stereotype.Service;
 import com.vc.entity.Citizens;
 import com.vc.entity.VaccinationCenter;
 import com.vc.repository.VaccinationcenterRepository;
 @Service
 public class VaccinationcenterService {
 @Autowired
 VaccinationcenterRepository vaccinationCenterRepository;
 public String storeVaccinationcenterDetails(VaccinationCenter vc) {
 Optional<VaccinationCenter> result = 
vaccinationCenterRepository.findById(vc.getCid());
 if (result.isPresent()) {
 return "Records didn't stored";
 } else {
 vaccinationCenterRepository.save(vc);
 return "VaccinationCenters records saved successfully";
 }
 }
 public List<VaccinationCenter> findAllVaccinationcenter() {
 return vaccinationCenterRepository.findAll();
}
 public String findSpecificVacctr(int cid) {
 Optional<VaccinationCenter> result = 
vaccinationCenterRepository.findById(cid);
 if (result.isPresent()) {
 VaccinationCenter c = result.get();
 return c.toString();
 } else {
 return "Details not present";
 }
 }
 