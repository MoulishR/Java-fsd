package pack1;

public class proaccessSpecifiers {

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}
