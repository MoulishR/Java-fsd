/**
 * 
 */
/**
 * 
 */
module diamondproblem {
}