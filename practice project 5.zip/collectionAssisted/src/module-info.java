/**
 * 
 */
/**
 * 
 */
module collectionAssisted {
}